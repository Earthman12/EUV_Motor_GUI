Sample Microsoft Win32 Console Application for the Oregon Micro Systems
MAXk Motor Controllers:
 - Link the application with the OmsMAXkMC.LIB, Motion controll DLL, import
   library.
   This library is located in the DLLs folder.
 - The header file OmsMAXkMC.H is also found in the DLLS folder.

